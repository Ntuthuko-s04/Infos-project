﻿namespace PhumlaKamnandiSystem.Presentation
{
    partial class CancelBooking
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.bookingIDtxt = new System.Windows.Forms.TextBox();
            this.bookingView = new System.Windows.Forms.ListView();
            this.CancelBtn = new System.Windows.Forms.Button();
            this.showBtn = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(449, 95);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(104, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Enter BookingID";
            // 
            // bookingIDtxt
            // 
            this.bookingIDtxt.Location = new System.Drawing.Point(415, 130);
            this.bookingIDtxt.Margin = new System.Windows.Forms.Padding(4);
            this.bookingIDtxt.Name = "bookingIDtxt";
            this.bookingIDtxt.Size = new System.Drawing.Size(173, 22);
            this.bookingIDtxt.TabIndex = 1;
            // 
            // bookingView
            // 
            this.bookingView.HideSelection = false;
            this.bookingView.Location = new System.Drawing.Point(212, 339);
            this.bookingView.Margin = new System.Windows.Forms.Padding(4);
            this.bookingView.Name = "bookingView";
            this.bookingView.Size = new System.Drawing.Size(575, 118);
            this.bookingView.TabIndex = 2;
            this.bookingView.UseCompatibleStateImageBehavior = false;
            this.bookingView.SelectedIndexChanged += new System.EventHandler(this.listView1_SelectedIndexChanged);
            // 
            // CancelBtn
            // 
            this.CancelBtn.Location = new System.Drawing.Point(415, 497);
            this.CancelBtn.Margin = new System.Windows.Forms.Padding(4);
            this.CancelBtn.Name = "CancelBtn";
            this.CancelBtn.Size = new System.Drawing.Size(188, 28);
            this.CancelBtn.TabIndex = 3;
            this.CancelBtn.Text = "Cancel Booking";
            this.CancelBtn.UseVisualStyleBackColor = true;
            // 
            // showBtn
            // 
            this.showBtn.Location = new System.Drawing.Point(415, 177);
            this.showBtn.Margin = new System.Windows.Forms.Padding(4);
            this.showBtn.Name = "showBtn";
            this.showBtn.Size = new System.Drawing.Size(175, 28);
            this.showBtn.TabIndex = 4;
            this.showBtn.Text = "Show";
            this.showBtn.UseVisualStyleBackColor = true;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1067, 562);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 5;
            this.pictureBox1.TabStop = false;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dateTimePicker1.Location = new System.Drawing.Point(0, 0);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(1067, 22);
            this.dateTimePicker1.TabIndex = 6;
            // 
            // CancelBooking
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1067, 554);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.showBtn);
            this.Controls.Add(this.CancelBtn);
            this.Controls.Add(this.bookingView);
            this.Controls.Add(this.bookingIDtxt);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "CancelBooking";
            this.Text = "CancelBooking";
            this.Load += new System.EventHandler(this.CancelBooking_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox bookingIDtxt;
        private System.Windows.Forms.ListView bookingView;
        private System.Windows.Forms.Button CancelBtn;
        private System.Windows.Forms.Button showBtn;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
    }
}