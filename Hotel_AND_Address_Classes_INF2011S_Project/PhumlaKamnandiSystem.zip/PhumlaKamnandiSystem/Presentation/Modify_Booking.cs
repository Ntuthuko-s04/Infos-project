﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PhumlaKamnandiSystem.Presentation
{
    public partial class Modify_Booking : Form
    {
        public Modify_Booking()
        {
            InitializeComponent();
        }

        private void bookingView_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void checkroomavailibility_Click(object sender, EventArgs e)
        {
            Room_Availibility r = new Room_Availibility();
            r.ShowDialog();
        }
    }
}
