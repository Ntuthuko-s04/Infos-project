﻿namespace PhumlaKamnandiSystem.Presentation
{
    partial class Reports
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtNoOfCancellations = new System.Windows.Forms.TextBox();
            this.txtCancellationRate = new System.Windows.Forms.TextBox();
            this.txtTotalrRevenue = new System.Windows.Forms.TextBox();
            this.txtTotalBookings = new System.Windows.Forms.TextBox();
            this.txtAvergaeStay = new System.Windows.Forms.TextBox();
            this.txtNoOfGuests = new System.Windows.Forms.TextBox();
            this.lblNoOfCancellations = new System.Windows.Forms.Label();
            this.lbleCancellationrate = new System.Windows.Forms.Label();
            this.lblTotalRevenue = new System.Windows.Forms.Label();
            this.lblTotalBookings = new System.Windows.Forms.Label();
            this.lblaverageStay = new System.Windows.Forms.Label();
            this.lblNoOfGuests = new System.Windows.Forms.Label();
            this.Invoice = new System.Windows.Forms.GroupBox();
            this.CheckOutdateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.CheckInDateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.txtDateTime = new System.Windows.Forms.TextBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.lblInvoiceDateTime = new System.Windows.Forms.Label();
            this.lblCheckOutDate = new System.Windows.Forms.Label();
            this.lblCheckInDate = new System.Windows.Forms.Label();
            this.lblInvoiceID = new System.Windows.Forms.Label();
            this.lblGuest = new System.Windows.Forms.Label();
            this.lblHotel = new System.Windows.Forms.Label();
            this.lblRoom = new System.Windows.Forms.Label();
            this.btnSeasonalReport = new System.Windows.Forms.Button();
            this.btnInvoice = new System.Windows.Forms.Button();
            this.btnAllReports = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.groupBox1.SuspendLayout();
            this.Invoice.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtNoOfCancellations);
            this.groupBox1.Controls.Add(this.txtCancellationRate);
            this.groupBox1.Controls.Add(this.txtTotalrRevenue);
            this.groupBox1.Controls.Add(this.txtTotalBookings);
            this.groupBox1.Controls.Add(this.txtAvergaeStay);
            this.groupBox1.Controls.Add(this.txtNoOfGuests);
            this.groupBox1.Controls.Add(this.lblNoOfCancellations);
            this.groupBox1.Controls.Add(this.lbleCancellationrate);
            this.groupBox1.Controls.Add(this.lblTotalRevenue);
            this.groupBox1.Controls.Add(this.lblTotalBookings);
            this.groupBox1.Controls.Add(this.lblaverageStay);
            this.groupBox1.Controls.Add(this.lblNoOfGuests);
            this.groupBox1.Location = new System.Drawing.Point(9, 8);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox1.Size = new System.Drawing.Size(277, 303);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Seasonal Report";
            // 
            // txtNoOfCancellations
            // 
            this.txtNoOfCancellations.Location = new System.Drawing.Point(191, 220);
            this.txtNoOfCancellations.Margin = new System.Windows.Forms.Padding(2);
            this.txtNoOfCancellations.Name = "txtNoOfCancellations";
            this.txtNoOfCancellations.Size = new System.Drawing.Size(68, 22);
            this.txtNoOfCancellations.TabIndex = 11;
            // 
            // txtCancellationRate
            // 
            this.txtCancellationRate.Location = new System.Drawing.Point(185, 177);
            this.txtCancellationRate.Margin = new System.Windows.Forms.Padding(2);
            this.txtCancellationRate.Name = "txtCancellationRate";
            this.txtCancellationRate.Size = new System.Drawing.Size(68, 22);
            this.txtCancellationRate.TabIndex = 10;
            // 
            // txtTotalrRevenue
            // 
            this.txtTotalrRevenue.Location = new System.Drawing.Point(185, 140);
            this.txtTotalrRevenue.Margin = new System.Windows.Forms.Padding(2);
            this.txtTotalrRevenue.Name = "txtTotalrRevenue";
            this.txtTotalrRevenue.Size = new System.Drawing.Size(68, 22);
            this.txtTotalrRevenue.TabIndex = 9;
            // 
            // txtTotalBookings
            // 
            this.txtTotalBookings.Location = new System.Drawing.Point(185, 104);
            this.txtTotalBookings.Margin = new System.Windows.Forms.Padding(2);
            this.txtTotalBookings.Name = "txtTotalBookings";
            this.txtTotalBookings.Size = new System.Drawing.Size(68, 22);
            this.txtTotalBookings.TabIndex = 8;
            // 
            // txtAvergaeStay
            // 
            this.txtAvergaeStay.Location = new System.Drawing.Point(185, 68);
            this.txtAvergaeStay.Margin = new System.Windows.Forms.Padding(2);
            this.txtAvergaeStay.Name = "txtAvergaeStay";
            this.txtAvergaeStay.Size = new System.Drawing.Size(68, 22);
            this.txtAvergaeStay.TabIndex = 7;
            // 
            // txtNoOfGuests
            // 
            this.txtNoOfGuests.Location = new System.Drawing.Point(185, 26);
            this.txtNoOfGuests.Margin = new System.Windows.Forms.Padding(2);
            this.txtNoOfGuests.Name = "txtNoOfGuests";
            this.txtNoOfGuests.Size = new System.Drawing.Size(68, 22);
            this.txtNoOfGuests.TabIndex = 6;
            // 
            // lblNoOfCancellations
            // 
            this.lblNoOfCancellations.AutoSize = true;
            this.lblNoOfCancellations.Location = new System.Drawing.Point(8, 221);
            this.lblNoOfCancellations.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblNoOfCancellations.Name = "lblNoOfCancellations";
            this.lblNoOfCancellations.Size = new System.Drawing.Size(153, 16);
            this.lblNoOfCancellations.TabIndex = 5;
            this.lblNoOfCancellations.Text = "Number of Cancellations";
            // 
            // lbleCancellationrate
            // 
            this.lbleCancellationrate.AutoSize = true;
            this.lbleCancellationrate.Location = new System.Drawing.Point(8, 177);
            this.lbleCancellationrate.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbleCancellationrate.Name = "lbleCancellationrate";
            this.lbleCancellationrate.Size = new System.Drawing.Size(113, 16);
            this.lbleCancellationrate.TabIndex = 4;
            this.lbleCancellationrate.Text = "Cancellation Rate";
            // 
            // lblTotalRevenue
            // 
            this.lblTotalRevenue.AutoSize = true;
            this.lblTotalRevenue.Location = new System.Drawing.Point(8, 144);
            this.lblTotalRevenue.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblTotalRevenue.Name = "lblTotalRevenue";
            this.lblTotalRevenue.Size = new System.Drawing.Size(96, 16);
            this.lblTotalRevenue.TabIndex = 3;
            this.lblTotalRevenue.Text = "Total Revenue";
            // 
            // lblTotalBookings
            // 
            this.lblTotalBookings.AutoSize = true;
            this.lblTotalBookings.Location = new System.Drawing.Point(8, 108);
            this.lblTotalBookings.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblTotalBookings.Name = "lblTotalBookings";
            this.lblTotalBookings.Size = new System.Drawing.Size(98, 16);
            this.lblTotalBookings.TabIndex = 2;
            this.lblTotalBookings.Text = "Total Bookings";
            // 
            // lblaverageStay
            // 
            this.lblaverageStay.AutoSize = true;
            this.lblaverageStay.Location = new System.Drawing.Point(5, 70);
            this.lblaverageStay.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblaverageStay.Name = "lblaverageStay";
            this.lblaverageStay.Size = new System.Drawing.Size(87, 16);
            this.lblaverageStay.TabIndex = 1;
            this.lblaverageStay.Text = "Average stay";
            // 
            // lblNoOfGuests
            // 
            this.lblNoOfGuests.AutoSize = true;
            this.lblNoOfGuests.Location = new System.Drawing.Point(5, 28);
            this.lblNoOfGuests.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblNoOfGuests.Name = "lblNoOfGuests";
            this.lblNoOfGuests.Size = new System.Drawing.Size(114, 16);
            this.lblNoOfGuests.TabIndex = 0;
            this.lblNoOfGuests.Text = "Number of Guests";
            // 
            // Invoice
            // 
            this.Invoice.Controls.Add(this.CheckOutdateTimePicker2);
            this.Invoice.Controls.Add(this.CheckInDateTimePicker2);
            this.Invoice.Controls.Add(this.txtDateTime);
            this.Invoice.Controls.Add(this.textBox10);
            this.Invoice.Controls.Add(this.textBox9);
            this.Invoice.Controls.Add(this.textBox8);
            this.Invoice.Controls.Add(this.textBox7);
            this.Invoice.Controls.Add(this.lblInvoiceDateTime);
            this.Invoice.Controls.Add(this.lblCheckOutDate);
            this.Invoice.Controls.Add(this.lblCheckInDate);
            this.Invoice.Controls.Add(this.lblInvoiceID);
            this.Invoice.Controls.Add(this.lblGuest);
            this.Invoice.Controls.Add(this.lblHotel);
            this.Invoice.Controls.Add(this.lblRoom);
            this.Invoice.Location = new System.Drawing.Point(329, 8);
            this.Invoice.Margin = new System.Windows.Forms.Padding(2);
            this.Invoice.Name = "Invoice";
            this.Invoice.Padding = new System.Windows.Forms.Padding(2);
            this.Invoice.Size = new System.Drawing.Size(419, 303);
            this.Invoice.TabIndex = 1;
            this.Invoice.TabStop = false;
            this.Invoice.Text = "Invoice";
            this.Invoice.Enter += new System.EventHandler(this.Invoice_Enter);
            // 
            // CheckOutdateTimePicker2
            // 
            this.CheckOutdateTimePicker2.Location = new System.Drawing.Point(146, 196);
            this.CheckOutdateTimePicker2.Margin = new System.Windows.Forms.Padding(2);
            this.CheckOutdateTimePicker2.Name = "CheckOutdateTimePicker2";
            this.CheckOutdateTimePicker2.Size = new System.Drawing.Size(247, 22);
            this.CheckOutdateTimePicker2.TabIndex = 16;
            // 
            // CheckInDateTimePicker2
            // 
            this.CheckInDateTimePicker2.Location = new System.Drawing.Point(146, 163);
            this.CheckInDateTimePicker2.Margin = new System.Windows.Forms.Padding(2);
            this.CheckInDateTimePicker2.Name = "CheckInDateTimePicker2";
            this.CheckInDateTimePicker2.Size = new System.Drawing.Size(247, 22);
            this.CheckInDateTimePicker2.TabIndex = 15;
            // 
            // txtDateTime
            // 
            this.txtDateTime.Location = new System.Drawing.Point(146, 229);
            this.txtDateTime.Margin = new System.Windows.Forms.Padding(2);
            this.txtDateTime.Name = "txtDateTime";
            this.txtDateTime.Size = new System.Drawing.Size(68, 22);
            this.txtDateTime.TabIndex = 14;
            // 
            // textBox10
            // 
            this.textBox10.Location = new System.Drawing.Point(146, 127);
            this.textBox10.Margin = new System.Windows.Forms.Padding(2);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(68, 22);
            this.textBox10.TabIndex = 11;
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(146, 94);
            this.textBox9.Margin = new System.Windows.Forms.Padding(2);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(68, 22);
            this.textBox9.TabIndex = 10;
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(146, 59);
            this.textBox8.Margin = new System.Windows.Forms.Padding(2);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(68, 22);
            this.textBox8.TabIndex = 9;
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(146, 24);
            this.textBox7.Margin = new System.Windows.Forms.Padding(2);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(68, 22);
            this.textBox7.TabIndex = 8;
            // 
            // lblInvoiceDateTime
            // 
            this.lblInvoiceDateTime.AutoSize = true;
            this.lblInvoiceDateTime.Location = new System.Drawing.Point(8, 233);
            this.lblInvoiceDateTime.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblInvoiceDateTime.Name = "lblInvoiceDateTime";
            this.lblInvoiceDateTime.Size = new System.Drawing.Size(113, 16);
            this.lblInvoiceDateTime.TabIndex = 6;
            this.lblInvoiceDateTime.Text = "Invoice Date&Time";
            this.lblInvoiceDateTime.Click += new System.EventHandler(this.lblInvoiceDateTime_Click);
            // 
            // lblCheckOutDate
            // 
            this.lblCheckOutDate.AutoSize = true;
            this.lblCheckOutDate.Location = new System.Drawing.Point(8, 200);
            this.lblCheckOutDate.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblCheckOutDate.Name = "lblCheckOutDate";
            this.lblCheckOutDate.Size = new System.Drawing.Size(101, 16);
            this.lblCheckOutDate.TabIndex = 5;
            this.lblCheckOutDate.Text = "Check-Out Date";
            // 
            // lblCheckInDate
            // 
            this.lblCheckInDate.AutoSize = true;
            this.lblCheckInDate.Location = new System.Drawing.Point(8, 163);
            this.lblCheckInDate.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblCheckInDate.Name = "lblCheckInDate";
            this.lblCheckInDate.Size = new System.Drawing.Size(91, 16);
            this.lblCheckInDate.TabIndex = 4;
            this.lblCheckInDate.Text = "Check-In Date";
            // 
            // lblInvoiceID
            // 
            this.lblInvoiceID.AutoSize = true;
            this.lblInvoiceID.Location = new System.Drawing.Point(8, 127);
            this.lblInvoiceID.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblInvoiceID.Name = "lblInvoiceID";
            this.lblInvoiceID.Size = new System.Drawing.Size(66, 16);
            this.lblInvoiceID.TabIndex = 3;
            this.lblInvoiceID.Text = "Invoice ID";
            // 
            // lblGuest
            // 
            this.lblGuest.AutoSize = true;
            this.lblGuest.Location = new System.Drawing.Point(8, 96);
            this.lblGuest.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblGuest.Name = "lblGuest";
            this.lblGuest.Size = new System.Drawing.Size(42, 16);
            this.lblGuest.TabIndex = 2;
            this.lblGuest.Text = "Guest";
            // 
            // lblHotel
            // 
            this.lblHotel.AutoSize = true;
            this.lblHotel.Location = new System.Drawing.Point(8, 59);
            this.lblHotel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblHotel.Name = "lblHotel";
            this.lblHotel.Size = new System.Drawing.Size(39, 16);
            this.lblHotel.TabIndex = 1;
            this.lblHotel.Text = "Hotel";
            // 
            // lblRoom
            // 
            this.lblRoom.AutoSize = true;
            this.lblRoom.Location = new System.Drawing.Point(5, 28);
            this.lblRoom.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblRoom.Name = "lblRoom";
            this.lblRoom.Size = new System.Drawing.Size(44, 16);
            this.lblRoom.TabIndex = 0;
            this.lblRoom.Text = "Room";
            // 
            // btnSeasonalReport
            // 
            this.btnSeasonalReport.Location = new System.Drawing.Point(81, 362);
            this.btnSeasonalReport.Margin = new System.Windows.Forms.Padding(2);
            this.btnSeasonalReport.Name = "btnSeasonalReport";
            this.btnSeasonalReport.Size = new System.Drawing.Size(197, 38);
            this.btnSeasonalReport.TabIndex = 2;
            this.btnSeasonalReport.Text = "Generate Seasonal Report";
            this.btnSeasonalReport.UseVisualStyleBackColor = true;
            // 
            // btnInvoice
            // 
            this.btnInvoice.Location = new System.Drawing.Point(437, 363);
            this.btnInvoice.Margin = new System.Windows.Forms.Padding(2);
            this.btnInvoice.Name = "btnInvoice";
            this.btnInvoice.Size = new System.Drawing.Size(165, 35);
            this.btnInvoice.TabIndex = 3;
            this.btnInvoice.Text = "Generate Invoice";
            this.btnInvoice.UseVisualStyleBackColor = true;
            // 
            // btnAllReports
            // 
            this.btnAllReports.Location = new System.Drawing.Point(285, 433);
            this.btnAllReports.Margin = new System.Windows.Forms.Padding(2);
            this.btnAllReports.Name = "btnAllReports";
            this.btnAllReports.Size = new System.Drawing.Size(171, 32);
            this.btnAllReports.TabIndex = 4;
            this.btnAllReports.Text = "Generate All Reports";
            this.btnAllReports.UseVisualStyleBackColor = true;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox1.Image = global::PhumlaKamnandiSystem.Properties.Resources.logo_color;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(764, 513);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 5;
            this.pictureBox1.TabStop = false;
            // 
            // Reports
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(764, 513);
            this.Controls.Add(this.btnAllReports);
            this.Controls.Add(this.btnInvoice);
            this.Controls.Add(this.btnSeasonalReport);
            this.Controls.Add(this.Invoice);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.pictureBox1);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Reports";
            this.Text = "Reports";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.Invoice.ResumeLayout(false);
            this.Invoice.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label lblNoOfCancellations;
        private System.Windows.Forms.Label lbleCancellationrate;
        private System.Windows.Forms.Label lblTotalRevenue;
        private System.Windows.Forms.Label lblTotalBookings;
        private System.Windows.Forms.Label lblaverageStay;
        private System.Windows.Forms.Label lblNoOfGuests;
        private System.Windows.Forms.GroupBox Invoice;
        private System.Windows.Forms.Button btnSeasonalReport;
        private System.Windows.Forms.Button btnInvoice;
        private System.Windows.Forms.Button btnAllReports;
        private System.Windows.Forms.TextBox txtNoOfCancellations;
        private System.Windows.Forms.TextBox txtCancellationRate;
        private System.Windows.Forms.TextBox txtTotalrRevenue;
        private System.Windows.Forms.TextBox txtTotalBookings;
        private System.Windows.Forms.TextBox txtAvergaeStay;
        private System.Windows.Forms.TextBox txtNoOfGuests;
        private System.Windows.Forms.TextBox txtDateTime;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.Label lblInvoiceDateTime;
        private System.Windows.Forms.Label lblCheckOutDate;
        private System.Windows.Forms.Label lblCheckInDate;
        private System.Windows.Forms.Label lblInvoiceID;
        private System.Windows.Forms.Label lblGuest;
        private System.Windows.Forms.Label lblHotel;
        private System.Windows.Forms.Label lblRoom;
        private System.Windows.Forms.DateTimePicker CheckOutdateTimePicker2;
        private System.Windows.Forms.DateTimePicker CheckInDateTimePicker2;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}

