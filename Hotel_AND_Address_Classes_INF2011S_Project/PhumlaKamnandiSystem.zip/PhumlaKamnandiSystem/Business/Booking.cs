﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PhumlaKamnandiSystem.Business
{
    internal class Booking
    {
        private int _BookingReference;
        private int _RoomID;
        public enum Status
        {
            Reserved,
            NotPaid,
            Cancelled,
            NotConfirmed,
            NotAvailable
        }
        private int _GuestId;
        public Status status;

        public Status GetStatus
        {
            get { return status; }
            set { status = value; }
        }

        public int BookingReference
        {
            get { return _BookingReference; }
            set { _BookingReference = value; }
        }

        public int RoomId
        {
            get { return _RoomID; }
            set { _RoomID = value;  }
        }
        
        public int GuestId
        {
            get { return _GuestId; }
            set { _GuestId = value; }
        }
        public Booking()
        {

        }
        public Booking(int bookingRef, int roomId, int guestId)
        {
            this._BookingReference = bookingRef;
            this._RoomID = roomId;
            this._GuestId = guestId;
        }

    }
}
