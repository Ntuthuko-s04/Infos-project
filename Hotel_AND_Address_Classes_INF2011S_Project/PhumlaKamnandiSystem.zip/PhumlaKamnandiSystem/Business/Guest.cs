﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PhumlaKamnandiSystem.Business
{
    internal class Guest
    {
        private int _guestId;
        private string _name;
        private string _surname;
        private int _cellPhoneNumber;
        private string _email;
        private int _memberShipId;

        public int GuestId
        {
            get { return _guestId; }
            set { _guestId = value; } 
        }

        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }

        public string Surname
        {
            get => _surname;
            set { _surname = value; }
        }
        public int MemberShipId
        {
            get { return _memberShipId; }
            set { _memberShipId = value; }
        }

        public string Email
        {
            get { return _email; }
            set { _email = value; }
        }

        public int CellPhoneNumber
        {
            get { return _cellPhoneNumber; }
            set { _cellPhoneNumber = value; }
        }

        public Guest()
        {

        }
        public Guest(int guestId, string name, int cellNum, int memberShip, string email)
        {
            _guestId = guestId;
            _name = name;
            _cellPhoneNumber = cellNum;
            _memberShipId = memberShip;
            _email = email;

        }
    }
}
