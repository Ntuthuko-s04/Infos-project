﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PhumlaKamnandiSystem.Business
{
    internal class Hotel
    {
        private int _HotelId;
        private string _Name;
        private Address _Address;
        private int _Capacity;
        private string _City;

        public int HotelId
        {
            get { return _HotelId; }
            set { _HotelId = value; }
        }
        public string Name
        {
            get { return _Name; }
            set { _Name = value; }
        }

        public Address Address
        {
            get { return _Address; }
            set { _Address = value; }
        }

        public int Capacity
        {
            get { return _Capacity; }
            set { _Capacity = value; }
        }

        public string City
        {
            get { return _City; }
            set { _City = value; }
        }

        public Hotel()
        {

        }
        public Hotel(int hotelId, string name, Address address, int capacity, string city)
        {
            this._HotelId = hotelId;
            this._Name = name;
            this._Address = address;
            this._Capacity = capacity;
            this._City = city;
        }

    }
}
